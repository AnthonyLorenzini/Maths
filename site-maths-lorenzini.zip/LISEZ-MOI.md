# Les maths de M. Lorenzini — mode d'emploi

## Ce que contient ce dossier

- `index.html` : l'accueil du site (niveaux, chapitres, recherche).
- `assets/catalogue.js` : **la liste de tout le contenu du site**. C'est le seul fichier à modifier pour ajouter, déplacer ou renommer une page.
- `assets/barre.js` : la petite barre en bas de chaque page (accueil, retour au chapitre, page suivante). Rien à modifier.
- `pages/` : une page par dossier (leçons, séances, mini-jeux).

## Mettre le site en ligne avec GitHub Pages (gratuit, une seule fois)

1. Crée un compte sur github.com (adresse perso ou académique).
2. Bouton **New repository** → nom : `maths` → coche **Public** → **Create repository**.
3. Sur la page du dépôt vide, clique sur **uploading an existing file**.
4. Glisse **le contenu** du dossier (pas le dossier lui-même) : `index.html`, `assets`, `pages`. Clique **Commit changes**.
5. Onglet **Settings** → **Pages** → Source : **Deploy from a branch**, branche **main**, dossier **/ (root)** → **Save**.
6. Une à deux minutes plus tard, l'adresse du site s'affiche en haut de cette page :
   `https://<ton-identifiant>.github.io/maths/`
   C'est ce lien à mettre sur Pearltrees ou à donner aux élèves. Il ne changera plus.

## Ajouter une nouvelle page (leçon, séance, mini-jeu, exercices en plus)

1. Dans le dépôt GitHub, ouvre `pages/` → **Add file** → **Upload files**, et dépose un dossier
   (par exemple `4e-ch4-lecon`) contenant le fichier `index.html` de la page.
2. Ouvre `assets/catalogue.js` → icône crayon → ajoute une ligne dans le bon chapitre :
   ```js
   { id: "4e-ch4-lecon", type: "lecon", titre: "Leçon — Pythagore", resume: "…", ajout: "2026-11-02" },
   ```
   Types : `lecon`, `exos` (corrigés en classe), `classe` (support projeté), `jeu`, `plus` (exercices supplémentaires corrigés).
3. Pour ouvrir un chapitre « Bientôt », retire `bientot: true`.
4. **Commit changes**. Le site se met à jour tout seul en une à deux minutes.

Pour qu'une nouvelle page ait la barre de navigation, ajoute juste avant `</body>` :
```html
<script src="../../assets/catalogue.js"></script>
<script src="../../assets/barre.js"></script>
```
(Claude peut aussi te préparer directement le dossier et la ligne à ajouter.)
